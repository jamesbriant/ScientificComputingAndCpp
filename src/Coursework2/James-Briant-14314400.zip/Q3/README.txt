- /data
Contains the output files with the data used to create the plots in the report.

- Lagrange.hpp
- Lagrange.cpp
Required for access to the lagrange polynomials used to estimate the functions.