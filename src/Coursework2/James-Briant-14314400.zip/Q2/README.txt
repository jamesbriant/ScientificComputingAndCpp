- AbstractQuadratureRule.hpp
- AbstractQuadratureRule.cpp
Required for the class Lagrange.

- Lagrange.hpp
- Lagrange.cpp
Required for access to the lagrange polynomials used to estimate the functions.